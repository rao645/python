package com.aws.test;
import java.util.Map;

import javax.naming.AuthenticationException;

import org.json.JSONException;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.Base64;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;


/**
 * @author venkat imadabattini
 *
 */

public class Test 
{

	private static String BASE_URL = null;
	private static String userCredentials = null;

	
	static
	{
		try
		{
			BASE_URL = "https://a5r304u3bb.execute-api.us-east-1.amazonaws.com/test/murthycalc?operand1=1&&operand2=2&&operator=%2B";

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {}

	}

	/**
	 * this method is to create the JSON request and making a call to post method.
	 */
	public static void callRestMethod() throws AuthenticationException, JSONException 
	{
		String userCredentials = "thisismurthy@gmail.com:Parnika1@3";
		String auth = new String(Base64.encode(userCredentials));
		
		
		
		try 
		{
			
			
			String  result = invokeGetMethod(auth,BASE_URL);
			
			System.out.println(result);
			
			// find tickets service now tickets in jira.
		
		} catch (ClientHandlerException e) {
			System.out.println("Error invoking REST method");
			e.printStackTrace();
		} 
	}
	
	/**
	 * 
	 * @param auth
	 * @param url
	 * @return
	 * @throws AuthenticationException
	 * @throws ClientHandlerException
	 */

	private static String invokeGetMethod(String auth, String url)
			throws AuthenticationException, ClientHandlerException {
		
		Client client = Client.create();
		WebResource webResource = client.resource(url);

		ClientResponse response = webResource.header("Authorization", "Basic " + auth).type("application/json")
				.accept("application/json").get(ClientResponse.class);

		int statusCode = response.getStatus();
		
		if (statusCode == 401) 
		{
			throw new AuthenticationException("Invalid Username or Password");
		}

		return response.getEntity(String.class);
	}

	/**
	 * test method.
	 * @param as
	 * @throws JSONException 
	 * @throws AuthenticationException 
	 */
	public static void main(String as[]) throws AuthenticationException, JSONException 
	{
		Test.callRestMethod();
	}

}
